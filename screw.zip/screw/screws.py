"""
https://colab.research.google.com/github/navidyou/Mask-RCNN-implementation-for-cell-nucleus-detection-executable-on-google-colab-/blob/master/mask_RCNN_cell_nucleus_google_colab.ipynb
Mask R-CNN
Configurations and data loading code for the synthetic Shapes dataset.
This is a duplicate of the code in the noteobook train_shapes.ipynb for easy
import into other notebooks, such as inspect_model.ipynb.

Copyright (c) 2017 Matterport, Inc.
Licensed under the MIT License (see LICENSE for details)
Written by Waleed Abdulla
"""

import os
import sys
import math
import random
import numpy as np
import cv2
import tkinter as tk
from tkinter import filedialog
from xml.etree import ElementTree

# Root directory of the project
#ROOT_DIR = os.path.abspath("../../")
print('Select the Root Directory of MaskRCNN')
root = tk.Tk()
root.withdraw()
ROOT_DIR = filedialog.askdirectory(title = 'MaskRCNN root dir')
# Import Mask RCNN
sys.path.append(ROOT_DIR)  # To find local version of the library
from mrcnn.config import Config
from mrcnn import utils

TRAIN_FOLDER = filedialog.askdirectory(title = 'Folder for training')
ANNOTATION_FOLDER = filedialog.askdirectory(title = 'Folder with Annotations')


class ScrewsConfig(Config):
    """Configuration for training on the toy shapes dataset.
    Derives from the base Config class and overrides values specific
    to the toy shapes dataset.
    """
    # Give the configuration a recognizable name
    NAME = "screws"

    # Train on 1 GPU and 8 images per GPU. We can put multiple images on each
    # GPU because the images are small. Batch size is 8 (GPUs * images/GPU).
    GPU_COUNT = 1
    IMAGES_PER_GPU = 2

    # Number of classes (including background)
    NUM_CLASSES = 1 + 1  # background + 3 shapes

    # Use small images for faster training. Set the limits of the small side
    # the large side, and that determines the image shape.
    IMAGE_MIN_DIM = 512
    IMAGE_MAX_DIM = 512

    # Use smaller anchors because our image and objects are small
    #RPN_ANCHOR_SCALES = (8, 16, 32, 64, 128)  # anchor side in pixels

    # Reduce training ROIs per image because the images are small and have
    # few objects. Aim to allow ROI sampling to pick 33% positive ROIs.
    TRAIN_ROIS_PER_IMAGE = 32

    # Use a small epoch since the data is simple
    STEPS_PER_EPOCH = 200

    # use small validation steps since the epoch is small
    VALIDATION_STEPS = 50


class ScrewsDataset(utils.Dataset):
    """Generates the shapes synthetic dataset. The dataset consists of simple
    shapes (triangles, squares, circles) placed randomly on a blank surface.
    The images are generated on the fly. No file access required.
    """

    def load_screws(self, mode = 'train', folder_path):
        """Generate the requested number of synthetic images.
        count: number of images to generate.
        height, width: the size of the generated images.
        """
        # Add classes
        self.add_class("shapes", 1, "screw")
        #self.add_class("shapes", 2, "circle")
        #self.add_class("shapes", 3, "triangle")

        # Add images
        # Generate random specifications of images (i.e. color and
        # list of shapes sizes and locations). This is more compact than
        # actual images. Images are generated on the fly in load_image().

        train_IDs = next(os.walk(folder_path))[2]
        if mode == 'train':
            for n, id_ in enumerate(train_IDs):
                if n < int(len(train_IDs * 0.9)):
                    path = folder + '/' + id_
                    annot = id_.strip('.png')
                    annot = annot + '.xml'
                    self.add_image("shape",image_id = n ,path = path,annotation = annot)
        if mode == 'val':
            for n, id_ in enumerate(train_IDs):
                if n >= int(len(train_IDs * 0.9)):
                    path = folder + '/' + id_
                    annot = id_.strip('.png')
                    annot = annot + '.xml'
                    self.add_image("shape",image_id = n ,path = path,annotation = annot)

    def rleDecode(self,rle,height,width,cnt):
        decode = np.zeros(height*width)
        count = ''
        iterator = 0
        for char in rle:

            if char.isdigit():
                count += char
            else:
                for i in range(int(count)):
                    decode[iterator] = False if char == 'F' else True
                    iterator += 1
                count = ''

        return decode.reshape((height,width,cnt))

    # extract bounding boxes from an annotation file
    def extract_boxes(self, filename):
        
        # load and parse the file
        tree = ElementTree.parse(filename)
        # get the root of the document
        root = tree.getroot()
        # extract each bounding box
        boxes = list()
        for box in root.findall('.//bndbox'):
            xmin = int(box.find('xmin').text)
            ymin = int(box.find('ymin').text)
            xmax = int(box.find('xmax').text)
            ymax = int(box.find('ymax').text)
            coors = [xmin, ymin, xmax, ymax]
            boxes.append(coors)
        
        # extract image dimensions
        width = int(root.find('.//size/width').text)
        height = int(root.find('.//size/height').text)
        return boxes, width, height
    

    

    def load_mask(self, image_id):
        """Generate instance masks for shapes of the given image ID.
        """
        info = self.image_info[image_id]
        path = info['path'].strip('.png') + '_0.png'
        #path_to_annot = info['annotation']
        f = open('/home/ondrej/Documents/MaskRCNN/datasets/screw/masks/masks.txt')
        lines = list(enumerate(f))
        index = 0
        
        for lin in lines:
            if lin[1].strip('\n') == path:
                index = lin[0]/2 + 1

        choice = lines[index]
        # load XML
        #boxes, w, h = self.extract_boxes(path_to_annot)
        class_ids = [1]
        # create one array for all masks, each on a different channel
        masks = self.rleDecode(choice[1],512,512,0)

        
        return masks, asarray(class_ids, dtype='int32')

    